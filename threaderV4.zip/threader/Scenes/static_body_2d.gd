extends CharacterBody2D

var is_stuck = false
var speed = 800.0
var gravity_force = 80.0

func launch(direction: Vector2):
	velocity = direction * speed
	rotation = direction.angle()

func _physics_process(delta: float) -> void:
	if is_stuck:
		return
	
	velocity.y += gravity_force * delta
	rotation = velocity.angle()
	
	move_and_slide()
	
	if get_slide_collision_count() > 0:
		var collision = get_slide_collision(0)
		# Nicht mit dem Igel selbst stecken bleiben
		if collision.get_collider() is CharacterBody2D:
			return
		is_stuck = true
		velocity = Vector2.ZERO
		set_physics_process(false)
