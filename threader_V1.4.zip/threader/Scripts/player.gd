extends CharacterBody2D
@export var speed = 300
@export var gravity = 30
@export var jump_force = 300
@onready var animated_sprite = $AnimatedSprite2D
var last_direction = 1
var was_on_floor = false



##animation aim wip
enum State { NORMAL, AIM, SPIT }
var state = State.NORMAL
var needle_count = 5

@onready var aim_body = $AimBody
@onready var aim_head = $AimHead







const BASE_SCALE = Vector2(0.044, 0.04)

func _physics_process(delta: float) -> void:
	var on_floor = is_on_floor()
	
	# Squash beim Landen
	if on_floor and !was_on_floor:
		animated_sprite.scale = Vector2(0.053, 0.034)
	
	# Smooth zurück zu normal
	animated_sprite.scale = animated_sprite.scale.lerp(BASE_SCALE, 0.2)
	
	was_on_floor = on_floor
	
	if !on_floor:
		velocity.y += gravity
		if velocity.y > 1000:
			velocity.y = 1000
	
	var horizontal_direction = Input.get_axis("move left", "move right")
	velocity.x = speed * horizontal_direction
	
	if horizontal_direction != 0:
		last_direction = horizontal_direction
	animated_sprite.flip_h = last_direction < 0
	
	# Animation-Priorität jump>walk>pause
	if !on_floor:
		animated_sprite.play("jump")
		if velocity.y < 0:
			animated_sprite.scale = Vector2(0.038, 0.048)  # steigt hoch
		else:
			#fällt scale wächst smooth mit fallgeschwindigkeit
			var fall_t = clamp(velocity.y / 100.0,0.0,1.0)# 0 = gerade losgelassen 1 = max speed
			var fall_scale_x = lerp(BASE_SCALE.x, 0.05,fall_t)
			var fall_scale_y = lerp(BASE_SCALE.y, 0.037,fall_t)
			animated_sprite.scale = Vector2(fall_scale_x,fall_scale_y) 
	elif horizontal_direction != 0:
		animated_sprite.play("walk")
	else:
		animated_sprite.play("pause")
	
	# Absprung
	if Input.is_action_just_pressed("jump") and on_floor:
		velocity.y = -jump_force
		animated_sprite.scale = Vector2(0.037, 0.052)
	
	move_and_slide()
	
	
	#aiming code and shooting code. no needle just char.
	
	
