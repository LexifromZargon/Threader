extends Area2D

@onready var animated_sprite = $AnimatedSprite2D  # ← das fehlte!


var is_picked_up = false

func _ready():
	$AnimatedSprite2D.centered = true

func _physics_process(delta: float) -> void:
	
	if not is_picked_up:
		animated_sprite.play("default")
