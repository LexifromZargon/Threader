extends CharacterBody2D

# ── Bewegungs-Einstellungen ──────────────────────────────────────────────────
@export var speed = 300
@export var gravity = 30
@export var jump_force = 800

# ── Node-Referenzen ──────────────────────────────────────────────────────────
@onready var animated_sprite = $AnimatedSprite2D
@onready var aim_body = $AimBody
@onready var aim_head = $AimHead
@onready var needleposition: Marker2D = $needleposition

# ── Bewegungs-Variablen ──────────────────────────────────────────────────────
var last_direction = 1
var was_on_floor = false

# ── Zustands-System ──────────────────────────────────────────────────────────
enum State { NORMAL, AIM, SPIT }
var state = State.NORMAL
var needle_count = 5

# ── Squash & Stretch ─────────────────────────────────────────────────────────
const BASE_SCALE = Vector2(0.44, 0.4)


func set_aim_mode(aiming: bool):
	animated_sprite.visible = !aiming
	aim_body.visible = aiming
	aim_head.visible = aiming


func _physics_process(delta: float) -> void:
	var on_floor = is_on_floor()

	# ── Squash beim Landen ───────────────────────────────────────────────────
	if on_floor and !was_on_floor:
		animated_sprite.scale = Vector2(0.53, 0.34)

	# Smooth zurück zur normalen Größe
	animated_sprite.scale = animated_sprite.scale.lerp(BASE_SCALE, 0.2)
	was_on_floor = on_floor

	# ── Schwerkraft ──────────────────────────────────────────────────────────
	if !on_floor:
		velocity.y += gravity
		if velocity.y > 1000:
			velocity.y = 1000

	# ── Horizontale Bewegung ─────────────────────────────────────────────────
	var horizontal_direction = Input.get_axis("move left", "move right")
	velocity.x = speed * horizontal_direction

	if horizontal_direction != 0:
		last_direction = horizontal_direction
	animated_sprite.flip_h = last_direction < 0

	# ── Animation-Priorität: Sprung > Walk > Idle ────────────────────────────
	if state == State.NORMAL:
		if !on_floor:
			animated_sprite.play("jump")
			if velocity.y < 0:
				animated_sprite.scale = Vector2(0.38, 0.48)
			else:
				var fall_t = clamp(velocity.y / 1000.0, 0.0, 1.0)
				var fall_scale_x = lerp(BASE_SCALE.x, 0.5, fall_t)
				var fall_scale_y = lerp(BASE_SCALE.y, 0.37, fall_t)
				animated_sprite.scale = Vector2(fall_scale_x, fall_scale_y)
		elif horizontal_direction != 0:
			animated_sprite.play("walk")
		else:
			animated_sprite.play("pause")

	# ── Springen ─────────────────────────────────────────────────────────────
	if Input.is_action_just_pressed("jump") and on_floor:
		velocity.y = -jump_force
		animated_sprite.scale = Vector2(0.37, 0.52)

	move_and_slide()

	# ── Aim / Spit Zustandsmaschine ──────────────────────────────────────────
	if Input.is_action_just_pressed("enable_shoot") and state == State.NORMAL:
		state = State.AIM
		set_aim_mode(true)

	if Input.is_action_just_released("enable_shoot") and state == State.AIM:
		state = State.NORMAL
		set_aim_mode(false)

	if Input.is_action_just_pressed("spit_it_out") and state == State.AIM:
		state = State.SPIT
		set_aim_mode(false)
		animated_sprite.play("spit")

	if state == State.SPIT and not animated_sprite.is_playing():
		if Input.is_action_pressed("enable_shoot"):
			state = State.AIM
			set_aim_mode(true)
		else:
			state = State.NORMAL
			set_aim_mode(false)

	# ── Kopf zur Maus drehen ─────────────────────────────────────────────────
	if state == State.AIM:
		var dir = get_global_mouse_position() - aim_head.global_position
		if last_direction < 0:
			dir.x *= -1
		var angle = clamp(dir.angle(), deg_to_rad(-50), deg_to_rad(50))
		aim_head.rotation = lerp_angle(aim_head.rotation, angle * last_direction, 0.15)


# ── Nadel aufheben — automatisch beim Reingehen ──────────────────────────────
func _on_range_area_entered(area: Area2D) -> void:
	if area.is_in_group("needle"):
		needle_count += 1
		area.queue_free()
		# update_needle_display() ← hier später Rücken-Nadeln updaten
