extends CharacterBody2D

# ── Bewegungs-Einstellungen ──────────────────────────────────────────────────
@export var speed = 300
@export var gravity = 30
@export var jump_force = 800

# ── Node-Referenzen ──────────────────────────────────────────────────────────
@onready var animated_sprite = $AnimatedSprite2D
@onready var aim_body = $AimBody
@onready var aim_head = $AimHead
@onready var needleposition: Marker2D = $needleposition
@onready var needle_label = $"../UI/HBoxContainer/Label"

# ── Bewegungs-Variablen ──────────────────────────────────────────────────────
var last_direction = 1
var was_on_floor = false
var SpitNeedle = preload("res://Scenes/static_body_2d.tscn")

# ── Zustands-System ──────────────────────────────────────────────────────────
enum State { NORMAL, AIM, SPIT }
var state = State.NORMAL

# ── Nadel-System ─────────────────────────────────────────────────────────────
var needle_count = 0
var max_needles_visible = 5

# ── Squash & Stretch ─────────────────────────────────────────────────────────
const BASE_SCALE = Vector2(0.44, 0.4)


func _ready():
	needle_label.text = "Needles: 0"
	update_needle_display()


func set_aim_mode(aiming: bool):
	# AnimatedSprite2D nur sichtbar im NORMAL-Modus
	animated_sprite.visible = !aiming
	if aim_body:
		aim_body.visible = aiming
	if aim_head:
		aim_head.visible = aiming


func shoot_needle():
	if needle_count <= 0:
		return
	needle_count -= 1
	update_needle_display()
	var needle = SpitNeedle.instantiate()
	get_parent().add_child(needle)
	needle.global_position = aim_head.global_position
	var dir = (get_global_mouse_position() - aim_head.global_position).normalized()
	needle.launch(dir)


func update_needle_display():
	needle_label.text = "Needles: " + str(needle_count)
	var back_needles = $BackNeedles
	for i in range(max_needles_visible):
		back_needles.get_child(i).visible = i < needle_count


func _physics_process(delta: float) -> void:
	var on_floor = is_on_floor()

	# ── Squash beim Landen ───────────────────────────────────────────────────
	if on_floor and !was_on_floor:
		animated_sprite.scale = Vector2(0.53, 0.34)

	animated_sprite.scale = animated_sprite.scale.lerp(BASE_SCALE, 0.2)
	$BackNeedles.scale.y = animated_sprite.scale.y / BASE_SCALE.y
	was_on_floor = on_floor

	# ── Schwerkraft ──────────────────────────────────────────────────────────
	if !on_floor:
		velocity.y += gravity
		if velocity.y > 1000:
			velocity.y = 1000

	# ── Bewegung nur im NORMAL-Modus ─────────────────────────────────────────
	var horizontal_direction = 0.0
	if state == State.NORMAL:
		horizontal_direction = Input.get_axis("move left", "move right")
	velocity.x = speed * horizontal_direction

	if horizontal_direction != 0:
		last_direction = horizontal_direction
	animated_sprite.flip_h = last_direction < 0
	$BackNeedles.scale.x = last_direction

	# ── Animation-Priorität ──────────────────────────────────────────────────
	if state == State.NORMAL:
		if !on_floor:
			animated_sprite.play("jump")
			if velocity.y < 0:
				animated_sprite.scale = Vector2(0.38, 0.48)
			else:
				var fall_t = clamp(velocity.y / 1000.0, 0.0, 1.0)
				animated_sprite.scale = Vector2(
					lerp(BASE_SCALE.x, 0.5, fall_t),
					lerp(BASE_SCALE.y, 0.37, fall_t)
				)
		elif horizontal_direction != 0:
			animated_sprite.play("walk")
		else:
			animated_sprite.play("pause")

	# ── Springen — nur im NORMAL-Modus ───────────────────────────────────────
	if Input.is_action_just_pressed("jump") and on_floor and state == State.NORMAL:
		velocity.y = -jump_force
		animated_sprite.scale = Vector2(0.37, 0.52)

	move_and_slide()

	# ── Aim / Spit Zustandsmaschine ──────────────────────────────────────────
	if Input.is_action_just_pressed("enable_shoot") and state == State.NORMAL:
		state = State.AIM
		set_aim_mode(true)

	if Input.is_action_just_released("enable_shoot") and state == State.AIM:
		state = State.NORMAL
		set_aim_mode(false)

	if Input.is_action_just_pressed("spit_it_out") and state == State.AIM:
		if needle_count > 0:
			state = State.SPIT
			set_aim_mode(false)
			# Spat-Animation spielen (einmalig, kein loop!)
			animated_sprite.play("spat")
			shoot_needle()

	# Nach Spat-Animation zurück zu Aim oder Normal
	if state == State.SPIT and not animated_sprite.is_playing():
		if Input.is_action_pressed("enable_shoot"):
			state = State.AIM
			set_aim_mode(true)
		else:
			state = State.NORMAL
			set_aim_mode(false)

	# ── Kopf zur Maus drehen (nur im AIM-Modus) ──────────────────────────────
	if state == State.AIM:
		var dir = get_global_mouse_position() - aim_head.global_position
		if last_direction < 0:
			dir.x *= -1
		var angle = clamp(dir.angle(), deg_to_rad(-50), deg_to_rad(50))
		aim_head.rotation = lerp_angle(aim_head.rotation, angle * last_direction, 0.15)


# ── Nadel aufheben ───────────────────────────────────────────────────────────
func _on_range_area_entered(area: Area2D) -> void:
	if area.is_in_group("needle"):
		needle_count += 1
		area.queue_free()
		update_needle_display()
