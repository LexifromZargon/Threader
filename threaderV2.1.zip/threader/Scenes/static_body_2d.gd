extends StaticBody2D

var velocity = Vector2.ZERO
var is_stuck = false
var speed = 800.0

func launch(direction: Vector2):
	velocity = direction * speed
	rotation = direction.angle()
	$CollisionShape2D.disabled = true

func _physics_process(delta: float) -> void:
	if is_stuck:
		return
	velocity.y += 15
	position += velocity * delta
	rotation = velocity.angle()

func _on_body_entered(body: Node2D) -> void:
	if is_stuck:
		return
	is_stuck = true
	velocity = Vector2.ZERO
	$CollisionShape2D.disabled = false
